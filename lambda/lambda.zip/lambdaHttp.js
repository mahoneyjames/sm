const htmlGenerator = require('./src/htmlGenerator');
const bucketName = "preview.storymarmalade.co.uk";

exports.publishStory = function(event, context, callback) {
    callback(null, "Success");
};

exports.publishStoryAsync = async (event, context) => {
    //console.log(event);

    switch(event.site)
    {
        case "preview":
            return htmlGenerator.buildAndPublishStory({siteName:"PREVIEW: Story Marmalade"},event.story,bucketName);
        default: 
            return "{errors:['No site specified']}";
    }
        
};
